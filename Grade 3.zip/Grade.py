#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# 1. Import required libraries and read the dataset. 


# In[1]:


import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt 
## get_ipython().run_line_magic('matplotlib', 'inline')

import sklearn
from sklearn.preprocessing import StandardScaler,MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingClassifier, AdaBoostClassifier, RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix

import warnings
warnings.filterwarnings('ignore')


# In[2]:


df = pd.read_csv('loan approval.csv')
df.head()


# In[5]:


# 2. Check the first few samples, shape, info of the data and try to familiarize yourself with different features.
def basic_info(df):
    '''checking basic information & shape about the dataframe'''
    temp=df.copy(deep=True)
    print("Shape of the dataset",df.shape)
    print("*"*30)
    print(df.info())
    
basic_info(df)


# In[ ]:


# In[6]:


# 3. Check for missing values in the dataset, if present? handle them with appropriate methods and drop redundant features.
df.isnull().sum()/len(df)*100


# In[ ]:



# In[7]:


## dropping missing values
df.dropna(inplace=True)


# In[8]:


## recheck the missing values
df.isnull().sum()


# In[9]:


## dropping redundant columns
df.drop('loan_id',axis=1,inplace=True)


# In[10]:


df.head(2)


# In[11]:


# 4. Visualize the distribution of the target column 'loan_status' with respect to various categorical features and write your observations. 
cat = []
num = []
for i in df.columns:
    if df[i].dtypes=='object':
        cat.append(i)
    else:
        num.append(i)      
print('The categorical variables are:\n',cat,'\n')
print('The numerical variables are:\n',num)


# In[12]:


categorical_features = df.select_dtypes(include=[object])
plt.figure(figsize=(30,25))
for i,label in enumerate(categorical_features):
    plt.subplot(6,3,i+1)
    ax = sns.countplot(df,x=label,hue = 'loan_status')


# In[ ]:


# In[13]:


# 5. Encode the categorical data
print(" Unique columns in Gender is ", df['gender'].unique())

print(" Unique columns in married is ", df['married'].unique())

print(" Unique columns in education is ", df['education'].unique())

print(" Unique columns in self_employed is ", df['self_employed'].unique())

print(" Unique columns in property_area is ", df['property_area'].unique())


# In[14]:


df['gender'] = df['gender'].replace({'male':1, 'female':2})

df['married'] = df['married'].replace({'yes':1, 'no':0})

df['education'] = df['education'].replace({'graduate':1, 'not graduate':0})

df['self_employed'] = df['self_employed'].replace({'no':0, 'yes':1})

df['property_area'] = df['property_area'].replace({'rural':0, 'urban':1, 'semiurban':2 })


# In[11]:


print(" Unique columns in Gender is ", df['gender'].unique())

print(" Unique columns in married is ", df['married'].unique())

print(" Unique columns in education is ", df['education'].unique())

print(" Unique columns in self_employed is ", df['self_employed'].unique())

print(" Unique columns in property_area is ", df['property_area'].unique())


# In[15]:


## lets check few rows after encoding
df.head(2)


# In[19]:


# 6. Separate the target and independent features and split the data into train and test.
X = df.drop('loan_status',axis=1)
y = df['loan_status']


# In[20]:


df['loan_status'].value_counts(normalize=True)*100


# In[21]:


X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.3,random_state=0)

print(X_train.shape,X_test.shape)
print(y_train.shape,y_test.shape)


# In[16]:


# 7. Build any classification model to predict the loan status of the customer and save your model using pickle.

## Let us build simple Adaptive Boosting classifier model
ab = AdaBoostClassifier()
ab.fit(X_train,y_train)


# In[17]:


## Let us check the accuracy to see hows our model is performing

y_train_pred = ab.predict(X_train)
y_test_pred = ab.predict(X_test)

accuracy_train = accuracy_score(y_train,y_train_pred)
accuracy_test = accuracy_score(y_test,y_test_pred)

print('accuracy train:',accuracy_train)
print('accuarcy test',accuracy_test)


# In[22]:


from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix,accuracy_score,f1_score


# In[23]:


rfc = RandomForestClassifier(n_estimators=250, random_state=250)
rfc.fit(X_train,y_train)


# In[24]:


y_pred = rfc.predict(X_test)


# In[25]:


accuracy_score(y_pred,y_test)


# In[26]:


confusion_matrix(y_pred,y_test)


# In[29]:


fi = rfc.feature_importances_


# In[30]:


plt.show()



import pickle
# Saving model to disk
pickle.dump(ab, open('model.pkl','wb'))

